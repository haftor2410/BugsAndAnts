#include "Ant.h"
#include "World.h"
#include <iostream>
using namespace std;

Ant::Ant(World* aWorld, int xcoord, int ycoord) : Organism(aWorld, xcoord, ycoord){
    
}
char Ant::representation() const{
    return 'o';
}
OrganismType Ant::getType() const{
    return ANT;
}
/*
 if(grid[i][j]->getBreed() >= BREED_BUGS ||
 grid[i][j]->getBreedNextTime() == true){
 */

void Ant::breed(){
    if(getBreed() >= BREED_ANTS || breedNextTime == true){
        breedAtAdjacentCell();
        setBreedToZero();
    }
}

void Ant::generateOffspring(int whereX, int whereY){
    setBreedNextTime(false);
    new Ant(world, whereX, whereY);
}

int Ant::size() const{
    return 10;
}

// Returns true if organism is dead, false otherwise.
bool Ant::isDead() const{
    return false;
}

void Ant::move(){
    Move temp = world->randomMove();
    if(temp == UP){
        actualMove(x, y + 1, getType());
    }
    if(temp == DOWN){
        actualMove(x, y - 1, getType());
    }
    if(temp == LEFT){
        actualMove(x - 1, y, getType());
    }
    if(temp == RIGHT){
        actualMove(x + 1, y, getType());
    }
}