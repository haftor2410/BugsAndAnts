#include "Bug.h"
#include "World.h"
using namespace std;

Bug::Bug(World* aWorld, int xcoord, int ycoord) : Organism(aWorld, xcoord, ycoord){
    myMoves = 0;
    notEatenRounds = 0;
}

char Bug::representation() const{
    return 'X';
}
OrganismType Bug::getType() const{
    return BUG;
}

int Bug::size() const{
    return 30;
}

void Bug::generateOffspring(int whereX, int whereY){
    setBreedNextTime(false);
    new Bug(world, whereX, whereY);
}

bool Bug::isDead() const{
    if(notEatenRounds >= STARVE_BUGS){
        return true;
    }
    return false;
}

void Bug::breed(){
    breedAtAdjacentCell();
    setBreedToZero();
}


void Bug::move(){
    myMoves++;
    if(bugTryToEat(x, y + 1)){
        notEatenRounds = 0;
        return;
    }
    else if(bugTryToEat(x, y - 1)){
        notEatenRounds = 0;
        return;
    }
    else if(bugTryToEat(x - 1, y)){
        notEatenRounds = 0;
        return;
    }
    else if(bugTryToEat(x + 1, y)){
        notEatenRounds = 0;
        return;
    }
    else{
        notEatenRounds++;
        Move temp = world->randomMove();
        
        if(temp == UP){
            actualMove(x, y + 1, getType());
        }
        if(temp == DOWN){
            actualMove(x, y - 1, getType());
        }
        if(temp == LEFT){
            actualMove(x - 1, y, getType());
        }
        if(temp == RIGHT){
            actualMove(x + 1, y, getType());
        }
    }
    isDead();
}

bool Bug::bugTryToEat(int inputX, int inputY){
    if(leagalPositionOrg(inputX, inputY)){
        if(world->getAt(inputX, inputY) != NULL){
            if(world->getAt(inputX, inputY)->getType() == ANT){
                delete world->getAt(inputX, inputY);
                //set nyja grid'id = gamla grid'id
                world->setAt(inputX, inputY, world->getAt(x, y));
                //NULL'a svo gamla
                world->setAt(x, y, NULL);
                //faeri svo ant
                movesTo(inputX, inputY);
                return true;
            }
        }
    }
    return false;
}

void Bug::setMymoves(int mov){
    myMoves = mov;
}

int Bug::getMyMoves(){
    return myMoves;
}
